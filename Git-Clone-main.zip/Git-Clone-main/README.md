# Git-Clone
A simple gitclone bot
